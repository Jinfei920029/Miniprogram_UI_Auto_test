__author__ = 'a633335'
#��ɫAPP
#apppackage = "com.bshg.homeconnect.android.ops"
#appActivity = "com.bshg.homeconnect.app.ui2019.navigation.BottomNavigationActivity"
#��ɫAPP
#apppackage = "com.bshg.homeconnect.android.dev"
#appActivity = "com.bshg.homeconnect.app.ui2019.navigation.BottomNavigationActivity"